from dotenv import load_dotenv
from task import create_search_task, create_analysis_task

load_dotenv()

if __name__ == "__main__":
    search = create_search_task("refund policy")
    analysis = create_analysis_task(search)
    output = analysis.execute()
    print("\n=== FINAL ANALYSIS ===\n", output)
