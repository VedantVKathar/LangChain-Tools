import os
from dotenv import load_dotenv
from crewai.tools import BaseTool
from langchain_community.tools.nuclia.tool import NucliaUnderstandingAPI
from pydantic import BaseModel, Field

# Load env vars for Nuclia SDK
load_dotenv()
os.environ["NUCLIA_ZONE"] = os.getenv("NUCLIA_ZONE", "")
os.environ["NUCLIA_NUA_KEY"] = os.getenv("NUCLIA_NUA_KEY", "")

class NucliaSearchInput(BaseModel):
    query: str = Field(..., description="Search query for Nuclia")

class NucliaSearchTool(BaseTool):
    name = "nuclia_search"
    description = (
        "Use Nuclia Understanding API to perform semantic search "
        "across your document knowledge base."
    )
    args_schema = NucliaSearchInput

    def __init__(self):
        super().__init__()
        # enable_ml=True for embeddings, summaries, etc.
        self.nuclia = NucliaUnderstandingAPI(enable_ml=True)

    def _run(self, query: str) -> str:
        return self.nuclia.run({"action": "search", "query": query})
