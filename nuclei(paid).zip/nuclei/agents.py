from crewai import Agent
from tools import NucliaSearchTool
from langchain_community.chat_models import ChatOllama

# Load environment variables if needed
from dotenv import load_dotenv
import os

load_dotenv()

# Optional: Set environment variables manually
os.environ["OLLAMA_MODEL"] = "llama3"

# Tool setup
nuclia_tool = NucliaSearchTool()

# Create a Document Search Specialist Agent
search_agent = Agent(
    role='Document Search Specialist',
    goal='Find relevant information from uploaded documents',
    verbose=True,
    memory=True,
    backstory=(
        "Expert at semantic search and summarization. Skilled at navigating through vast document datasets "
        "and finding the most contextually relevant information."
    ),
    tools=[nuclia_tool],
    llm=ChatOllama(model="llama3", temperature=0.1),
    allow_delegation=False
)

# Create a Document Analysis Expert Agent
analysis_agent = Agent(
    role='Document Analysis Expert',
    goal='Analyze and summarize document search results',
    verbose=True,
    memory=True,
    backstory=(
        "Expert at extracting actionable insights from documents. Focuses on producing concise, high-impact summaries "
        "that help decision-makers understand complex data quickly."
    ),
    tools=[],
    llm=ChatOllama(model="llama3", temperature=0.2),
    allow_delegation=False
)
