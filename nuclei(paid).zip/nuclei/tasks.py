from crewai import Task
from agents import create_search_agent, create_analysis_agent

def create_search_task(query: str) -> Task:
    return Task(
        description=f"Search for: {query}",
        expected_output="Summary of key findings from Nuclia",
        agent=create_search_agent()
    )

def create_analysis_task(search_task: Task) -> Task:
    return Task(
        description="Analyze search results for policy and insights",
        expected_output="Detailed analysis with key points and recommendations",
        agent=create_analysis_agent(),
        context=[search_task]
    )
